

/*this is the java script that is adding acvitity to MyProfile.html main documen*/


function save(){

	
    
 // validation to make sure no blank imputs are submitted
    var err = "";
    
    if (document.getElementById('Name_Of_Proj').value=="") {
    	err += "Enter the project name...\n";
    	document.getElementById('Name_Of_Projpname').style.borderColor = "red";
    }
    if (document.getElementById('Pro_Description').value=="") {
    	err += "Enter the project description...\n";
    	document.getElementById('Pro_Description').style.borderColor = "red";
    }
    if (document.getElementById('Completion_date').value=="") {
    	err += "Enter the project date...\n";
    	document.getElementById('Completion_date').style.borderColor = "red";
    }

    // an error message pops up to alert the user complete the form 
    if (err != "") {
    	alert(err);
    	return false;
    }

    confirm('Click To Confirm Form Submition!');

// Storing project input into the local storage
	var Proj_Name = document.getElementById('Name_Of_Proj').value;
	var Proj_Desc = document.getElementById('Pro_Description').value;
	var Proj_Date = document.getElementById('Completion_date').value;

	localStorage.setItem('Name_Of_Proj',Proj_Name);
	localStorage.setItem('Pro_Description',Proj_Desc);
	localStorage.setItem('Completion_date',Proj_Date);

alert('Form Successfully Submitted!');
 
}

// get the stored project inputs
function load(){
	var storedValue = localStorage.getItem('Name_Of_Proj');
	var storedValue = localStorage.getItem('Pro_Description');
	var storedValue = localStorage.getItem('Completion_date');
}
function clean(){

    confirm('Are you sure you want to clear your Project details?');

	localStorage.removeItem('Name_Of_Proj');
	localStorage.removeItem('Pro_Description');
	localStorage.removeItem('Completion_date');
}

// more about exprience details
function show(){

// validation code  
   var emptyinputvalue = "";
    
    if (document.getElementById('Org_Name').value=="") {
    	emptyinputvalue += "Enter the your exprience...\n";
    	document.getElementById('Org_Name').style.borderColor = "red";

    }
    

    if (document.getElementById('from').value=="") {
    	emptyinputvalue += "Enter the working date...\n";
    	document.getElementById('from').style.borderColor = "red";
    }

    if (document.getElementById('to').value=="") {
        emptyinputvalue += "Enter the working date...\n";
        document.getElementById('to').style.borderColor = "red";
    }
    if (emptyinputvalue != "") {
    	alert(emptyinputvalue);
    	return false;
    	
    }

   confirm('Press 'OK' to confirm form submission');

//set work exprience input	
    var workT = document.getElementById('Org_Name').value;

	 

	var workDate = document.getElementById('from').value;
    var workDate = document.getElementById('to').value;


    localStorage.setItem('Org_Name',workT);
	localStorage.setItem('from',workDate);
    localStorage.setItem('to',workDate);

 alert(' Form Successfully submitted: Click to see Project Details');
}
//gets the work exprience input
function work(){
	var storedValue = localStorage.getItem('Org_Name');
	var storedValue = localStorage.getItem('from');
    var storedValue = localStorage.getItem('to');
}


//it will going to clear all work exprience localstorage
function cleared(){
     confirm('Are you sure you want to clear your Project Details?')

	localStorage.removeItem('Org_Name');
	localStorage.removeItem('from');
    localStorage.removeItem('to');
}
